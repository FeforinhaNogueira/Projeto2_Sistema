// src/controllers/productController.js
const path = require('path');
const fs = require('fs');
const productModel = require('../models/productModel');

const getAllProducts = async (req, res) => {
    try {
        const products = await productModel.getAll();
        res.json(products);
    } catch (err) {
        res.status(500).json({ message: 'Erro ao buscar produtos' });
    }
};

const getProductById = async (req, res) => {
    try {
        const id = req.params.id;
        const product = await productModel.getById(id);
        if (!product) return res.status(404).json({ message: 'Produto não encontrado' });
        res.json(product);
    } catch (err) {
        res.status(500).json({ message: 'Erro ao buscar produto' });
    }
};

const createProduct = async (req, res) => {
    try {
        const { name, description, price } = req.body;
        let image_url = null;

        if (req.file) {
            image_url = `/uploads/produtos/${req.file.filename}`;
        }

        const product = { name, description, price, image_url };
        const id = await productModel.create(product);
        res.status(201).json({ id, ...product });
    } catch (err) {
        res.status(500).json({ message: 'Erro ao criar produto' });
    }
};

const updateProduct = async (req, res) => {
    try {
        const id = req.params.id;
        const { name, description, price, currentImageUrl, removeImage } = req.body;

        let image_url = currentImageUrl;

        if (req.file) {
            image_url = `/uploads/produtos/${req.file.filename}`;
        } else if (removeImage === 'true') {
            image_url = null;
        }

        const updatedProduct = { name, description, price, image_url };
        await productModel.update(id, updatedProduct);
        res.json({ id, ...updatedProduct });
    } catch (err) {
        res.status(500).json({ message: 'Erro ao atualizar produto' });
    }
};

const deleteProduct = async (req, res) => {
    try {
        const id = req.params.id;
        await productModel.remove(id);
        res.json({ message: 'Produto excluído com sucesso' });
    } catch (err) {
        res.status(500).json({ message: 'Erro ao excluir produto' });
    }
};

module.exports = {
    getAllProducts,
    getProductById,
    createProduct,
    updateProduct,
    deleteProduct
};
