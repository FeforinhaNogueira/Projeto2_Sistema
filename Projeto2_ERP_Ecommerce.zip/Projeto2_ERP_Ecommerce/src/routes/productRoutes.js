const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const {
    getAllProducts,
    getProductById,
    createProduct,
    updateProduct,
    deleteProduct
} = require('../controllers/productController');

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, path.join(__dirname, '../uploads/produtos'));
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage });

router.get('/', getAllProducts);
router.get('/:id', getProductById);
router.post('/', upload.single('imagemProduto'), createProduct);
router.put('/:id', upload.single('imagemProduto'), updateProduct);
router.delete('/:id', deleteProduct);

module.exports = router;
