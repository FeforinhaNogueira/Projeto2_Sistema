// src/models/productModel.js
const { pool } = require('../config/db');

const getAll = async () => {
    const [rows] = await pool.query('SELECT * FROM products');
    return rows;
};

const getById = async (id) => {
    const [rows] = await pool.query('SELECT * FROM products WHERE id = ?', [id]);
    return rows[0];
};

const create = async (product) => {
    const [result] = await pool.query('INSERT INTO products SET ?', [product]);
    return result.insertId;
};

const update = async (id, product) => {
    await pool.query('UPDATE products SET ? WHERE id = ?', [product, id]);
};

const remove = async (id) => {
    await pool.query('DELETE FROM products WHERE id = ?', [id]);
};

module.exports = { getAll, getById, create, update, remove };
