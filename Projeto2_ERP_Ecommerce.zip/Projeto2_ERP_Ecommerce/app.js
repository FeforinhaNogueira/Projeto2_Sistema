require('dotenv').config();
const express = require('express');
const path = require('path');
const { connectDB } = require('./src/config/db');
const productRoutes = require('./src/routes/productRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// Conecta ao banco de dados
connectDB();

// Middlewares para receber JSON e dados via form
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Servir uploads (imagens) estáticos
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Rotas API produtos
app.use('/api/products', productRoutes);

// Servir arquivos estáticos do frontend (css, js, imagens)
app.use(express.static(path.join(__dirname, 'src/site')));

// Rota raiz serve o index.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'src/site/index.html'));
});

// Inicia o servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
  console.log(`Frontend disponível em http://localhost:${PORT}`);
  console.log(`API de produtos em http://localhost:${PORT}/api/products`);
});
